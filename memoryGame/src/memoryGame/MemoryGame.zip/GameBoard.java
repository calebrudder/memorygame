package memoryGame;

import java.awt.Color;

import java.awt.GridLayout;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import static java.time.temporal.ChronoUnit.MINUTES;

import javax.swing.JPanel;

public class GameBoard extends JPanel {
	private final int ROWS = 4;
	private final int COLUMNS = 4;
	
	private LocalTime startTime;
	private LocalTime endTime;
	private boolean gameOver;
	
	private Card[][] cells = new Card[ROWS][COLUMNS];
	private Color[] colorOptions = { Color.red, Color.orange, 
							   Color.yellow, Color.green, 
							   Color.lightGray, Color.blue,
							   Color.magenta, Color.pink };

	private ArrayList<Color> colors = new ArrayList<Color>();
	
	private Card cardSelected;
	
	public GameBoard() {
		setLayout(new GridLayout(ROWS, COLUMNS));
		InitializeGameBoard();

	}

	private void InitializeGameBoard() {
		//boolean chosen = false;
		//boolean noColors = false;
		
		for (int i = 0; i < (ROWS * COLUMNS) / 2; i++) {
			Random rand = new Random();
			int colorIndex = rand.nextInt(colorOptions.length);
			
			colors.add(colorOptions[colorIndex]);
			colors.add(colorOptions[colorIndex]);
		}
		
		for (int row = 0; row < ROWS; row++) {
			for (int column = 0; column < COLUMNS; column++) {
				Card newCard = new Card("");
				
				Random rand = new Random();
				int colorIndex = rand.nextInt(colors.size());
				
				newCard.setCorrectColor(colors.get(colorIndex));
				colors.remove(colorIndex);
				
				newCard.setGameBoard(this);
				
				cells[row][column] = newCard;
				add(newCard);
			}
		}
		startTime = LocalTime.now();
	}
	
	public void cardClicked(Card card) throws IOException{
		if (!card.isMatched()) {
			if (cardSelected == null) {
				cardSelected = card;
			} else {
				compareCards(card);
			}
		}
	}
	
	public void compareCards(Card card) throws IOException {
		Timer t = new Timer();
		t.schedule(new TimerTask() {
			@Override
            public void run() {
				if (!card.equals(cardSelected)) {
					card.flipOver();
					cardSelected.flipOver();
					cardSelected = null;
				} else {
					card.setMatched(true);
					cardSelected.setMatched(true);
					cardSelected = null;
					try {
						checkBoard();
					} catch (IOException exception) {
						System.out.println(exception);
					}
				}
            }
        }, 1000);
	}
	
	private void checkBoard() throws IOException{
		gameOver = true;
		for (Card[] cards : cells) {
			for (Card card : cards) {
				if (!card.isMatched()) {
					gameOver = false;
				}
			}
		}
		if (gameOver) {
			endTime = LocalTime.now();
			
			PrintWriter outFile = new PrintWriter(new FileWriter("highscore.txt"));
			outFile.println(MINUTES.between(startTime, endTime));
			outFile.close();
		}
	}
}
