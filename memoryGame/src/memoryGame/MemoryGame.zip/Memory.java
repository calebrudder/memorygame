package memoryGame;

import java.awt.Button;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;

public class Memory extends JFrame {

	private GameBoard  gameBoard = new GameBoard();

	public static void main(String[] args) {
		Memory memory = new Memory();

	}

	public Memory() {
		setSize(200, 200);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		add(gameBoard);
		setVisible(true);
	}
}
